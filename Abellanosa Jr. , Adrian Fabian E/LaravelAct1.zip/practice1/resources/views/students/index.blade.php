@include('partials.header', ['title' => 'Student System'])
    <ul>
        @foreach ($students as $student )
        <li>{{ $student->first_name }}<br/> {{ $student->last_name  }}</li>            
        @endforeach
    </ul>
@include('partials.footer')