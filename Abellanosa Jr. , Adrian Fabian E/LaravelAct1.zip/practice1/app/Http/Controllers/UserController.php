<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View as FacadesView;

class UserController extends Controller
{
    public function index(){
        return "hello from user controller";
    }

    public function login(){
       if(FacadesView::exists('user.login')){
        return view('user.login');
       }else{
        return abort(404);
       }
    }

    public function register(){
        return view('user.register');
    }

    public function show($id){
    
        return view('user')
                ->with('name','AJ')
                ->with('age', 24)
                ->with('email','AJ@kodego.com')
                ->with('id',$id);
    }
}
