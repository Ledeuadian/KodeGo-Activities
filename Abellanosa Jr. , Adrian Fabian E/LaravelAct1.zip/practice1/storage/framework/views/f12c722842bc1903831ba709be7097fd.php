
<?php echo e($name); ?><?php /**PATH C:\Users\adria\OneDrive\Desktop\Laravel\practice1\resources\views/user.blade.php ENDPATH**/ ?>